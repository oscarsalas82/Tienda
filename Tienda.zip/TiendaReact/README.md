# TiendaReactWebNextU
Examen Next University Web de Tienda con React

Para probar la aplicación de debe tener instalado NodeJS, MongoDB y NPM.

Pueden usar los scripts que se encuentran en el archivo Package.json como compilación y prueba y para ponerlo en producción se debe usar el siguiente comando:

1. node server/iniciarData.js
2. verificar los datos creados en la BD de MongoDB.
3. npm run dist
4. node servernode.js
